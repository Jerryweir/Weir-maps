
const CACHE_NAME='broker-maps-v1';
const ASSETS=['./','./index.html','./FiberMap_Interactive_Sequentials.html','./Conduit_Structures_PM_Approval_Map.html','./HDD_Master_Dashboard_Wired.xlsx','./manifest.json','./assets/icon-192.png','./assets/icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.map(k=>k!==CACHE_NAME&&caches.delete(k))))) });
self.addEventListener('fetch',e=>{const u=new URL(e.request.url); if(u.origin===location.origin){ e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))) }});
