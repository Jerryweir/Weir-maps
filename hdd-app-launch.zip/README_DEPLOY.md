
# Deploy Instructions

## GitHub Pages
1) Create a repo and upload all files from this folder.
2) Settings → Pages → Deploy from Branch (main / root).
3) Your app will be live at `https://<your-user>.github.io/<repo>/`.

## Netlify
1) Drag & drop this folder into Netlify (app.netlify.com) or connect the repo.
2) Optional: add a custom domain like `maps.yourcompany.com`.

## Access Model
- Customer pays for the app and issues access. For now, the site is open-link; in Phase 2 we’ll add login/roles.
